<?php
// Server-side validation: never trust the browser.
header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); echo json_encode(['ok'=>false,'errors'=>['form'=>'POST only']]); exit; }

$in = fn($k) => trim($_POST[$k] ?? '');
$e = [];

foreach (['firstName','lastName'] as $k) {
  $l = mb_strlen($in($k));
  if ($l < 2 || $l > 30) $e[$k] = 'Must be 2 to 30 characters.';
}
if (!preg_match('/^[0-9]{10}$/', $in('studentNo'))) $e['studentNo'] = 'Student number must be exactly 10 digits.';
if (!filter_var($in('email'), FILTER_VALIDATE_EMAIL) || !preg_match('/@.+\.(edu|ac\.[a-z]{2,})$/i', $in('email')))
  $e['email'] = 'Enter a valid institutional email.';
if (!preg_match('/^\+?[0-9]{10,13}$/', $in('phone'))) $e['phone'] = 'Phone must be 10 to 13 digits.';
$age = filter_var($in('age'), FILTER_VALIDATE_INT, ['options'=>['min_range'=>16,'max_range'=>100]]);
if ($age === false) $e['age'] = 'Age must be a whole number from 16 to 100.';
if (!in_array($in('programme'), ['Computer Science','Information Systems','Engineering','Information Technology'], true)) $e['programme'] = 'Choose a valid programme.';
if (!in_array($in('year'), ['1','2','3'], true)) $e['year'] = 'Select a valid year.';
$allowed = ['Coding','Sports','Music','Debate'];
$ints = array_intersect((array)($_POST['interests'] ?? []), $allowed);
if (count(array_unique($ints)) < 2) $e['interests[]'] = 'Select at least two valid interests.';
$pw = $_POST['password'] ?? '';
if (strlen($pw) < 8 || strlen($pw) > 64 || !preg_match('/[A-Z]/',$pw) || !preg_match('/[a-z]/',$pw) || !preg_match('/\d/',$pw) || !preg_match('/[^A-Za-z0-9]/',$pw))
  $e['password'] = 'Password is too weak.';
if ($pw !== ($_POST['confirm'] ?? null)) $e['confirm'] = 'Passwords do not match.';

if ($e) { http_response_code(422); echo json_encode(['ok'=>false,'errors'=>$e]); exit; }

// Valid: a real app would store password_hash($pw, PASSWORD_DEFAULT) in MySQL here.
echo json_encode(['ok'=>true,'message'=>'Registration successful. Welcome, '.htmlspecialchars($in('firstName')).'!']);
