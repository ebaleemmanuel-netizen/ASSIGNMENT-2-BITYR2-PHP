<?php
// Simple server-side demonstration.
// IMPORTANT: Real applications should validate and sanitize every value again.

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $fullName = htmlspecialchars($_POST["fullName"] ?? "");
    $studentNumber = htmlspecialchars($_POST["studentNumber"] ?? "");
    $email = htmlspecialchars($_POST["email"] ?? "");

    echo "<h1>Form Received</h1>";
    echo "<p><strong>Name:</strong> $fullName</p>";
    echo "<p><strong>Student Number:</strong> $studentNumber</p>";
    echo "<p><strong>Email:</strong> $email</p>";
    echo "<p>The server received the POST request successfully.</p>";
} else {
    echo "No POST request received.";
}
?>
