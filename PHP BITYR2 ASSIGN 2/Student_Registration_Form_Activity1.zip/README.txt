STUDENT REGISTRATION FORM - CLASS ACTIVITY 1

Files:
1. index.html  - Form structure and HTML5 validation attributes
2. style.css   - Form design
3. script.js   - JavaScript validation and user feedback
4. process.php - Simple server-side demonstration

HOW TO RUN:
1. Put all four files in a folder inside XAMPP's htdocs folder.
2. Start Apache in XAMPP.
3. Open:
   http://localhost/student_registration_activity/index.html

HTML5 VALIDATION:
- required: makes fields compulsory.
- type="email": checks email format.
- pattern: checks telephone and student number format.
- minlength/maxlength: controls text length.
- min/max: controls numeric age.
- select required: requires a programme.
- radio buttons: require a year through JavaScript.
- checkboxes: JavaScript requires at least two.

JAVASCRIPT VALIDATION:
- Requires at least two interest checkboxes.
- Checks password strength.
- Confirms both passwords match.
- Displays inline error messages.
- Moves focus to the first invalid field.
- Displays a success message when validation passes.

NETWORK PANEL:
For a real POST request:
1. Make sure process.php is available.
2. In script.js, remove the first `event.preventDefault()` inside the submit handler.
3. Open browser Developer Tools -> Network.
4. Submit a valid form.
5. Click the process.php request.
6. Inspect the Request Method (POST), Form Data/Payload and Response.

SERVER-SIDE VALIDATION:
Client-side JavaScript improves user experience, but it is NOT a security boundary.
The server must validate the submitted values again before storing or processing them.
