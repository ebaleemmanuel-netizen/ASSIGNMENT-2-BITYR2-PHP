const form = document.getElementById("registrationForm");

const fullName = document.getElementById("fullName");
const studentNumber = document.getElementById("studentNumber");
const email = document.getElementById("email");
const telephone = document.getElementById("telephone");
const age = document.getElementById("age");
const programme = document.getElementById("programme");
const password = document.getElementById("password");
const confirmPassword = document.getElementById("confirmPassword");
const terms = document.getElementById("terms");

const successMessage = document.getElementById("successMessage");
const passwordStrength = document.getElementById("passwordStrength");

function setError(field, message) {
    field.classList.add("invalid");
    field.classList.remove("valid");

    const errorElement = document.getElementById(field.id + "Error");
    if (errorElement) {
        errorElement.textContent = message;
    }
}

function setValid(field) {
    field.classList.remove("invalid");
    field.classList.add("valid");

    const errorElement = document.getElementById(field.id + "Error");
    if (errorElement) {
        errorElement.textContent = "";
    }
}

function validatePasswordStrength() {
    const value = password.value;

    if (value.length === 0) {
        passwordStrength.textContent = "";
        return false;
    }

    const hasUppercase = /[A-Z]/.test(value);
    const hasLowercase = /[a-z]/.test(value);
    const hasNumber = /[0-9]/.test(value);

    if (value.length >= 8 && hasUppercase && hasLowercase && hasNumber) {
        passwordStrength.textContent = "Strong password";
        return true;
    } else {
        passwordStrength.textContent =
            "Weak password - use 8+ characters, uppercase, lowercase and a number.";
        return false;
    }
}

password.addEventListener("input", validatePasswordStrength);

form.addEventListener("submit", function(event) {
    event.preventDefault();

    // Clear previous messages
    successMessage.style.display = "none";

    document.querySelectorAll(".error").forEach(function(error) {
        error.textContent = "";
    });

    document.querySelectorAll("input, select").forEach(function(field) {
        field.classList.remove("invalid", "valid");
    });

    let firstInvalidField = null;
    let formIsValid = true;

    function fail(field, message) {
        setError(field, message);
        formIsValid = false;

        if (!firstInvalidField) {
            firstInvalidField = field;
        }
    }

    // Full name
    if (!fullName.checkValidity()) {
        fail(fullName, "Please enter your full name (3-60 characters).");
    } else {
        setValid(fullName);
    }

    // Student number
    if (!studentNumber.checkValidity()) {
        fail(studentNumber, "Enter a valid student number using 5-20 letters, numbers, / or -.");
    } else {
        setValid(studentNumber);
    }

    // Email
    if (!email.checkValidity()) {
        fail(email, "Please enter a valid institutional email address.");
    } else {
        setValid(email);
    }

    // Telephone
    if (!telephone.checkValidity()) {
        fail(telephone, "Enter a valid Ugandan telephone number, e.g. 0771234567.");
    } else {
        setValid(telephone);
    }

    // Age
    if (!age.checkValidity()) {
        fail(age, "Age must be between 15 and 60.");
    } else {
        setValid(age);
    }

    // Programme
    if (!programme.checkValidity()) {
        fail(programme, "Please select your programme.");
    } else {
        setValid(programme);
    }

    // Radio buttons
    const selectedYear = document.querySelector('input[name="year"]:checked');
    const yearError = document.getElementById("yearError");

    if (!selectedYear) {
        yearError.textContent = "Please select your year of study.";
        formIsValid = false;

        if (!firstInvalidField) {
            firstInvalidField = document.querySelector('input[name="year"]');
        }
    } else {
        yearError.textContent = "";
    }

    // Password
    if (!password.checkValidity()) {
        fail(password, "Password must contain at least 8 characters.");
    } else if (!validatePasswordStrength()) {
        fail(password, "Password is too weak.");
    } else {
        setValid(password);
    }

    // Confirm password
    if (!confirmPassword.value) {
        fail(confirmPassword, "Please confirm your password.");
    } else if (confirmPassword.value !== password.value) {
        fail(confirmPassword, "Passwords do not match.");
    } else {
        setValid(confirmPassword);
    }

    // At least two checkboxes
    const interests = document.querySelectorAll('input[name="interests"]:checked');
    const interestsError = document.getElementById("interestsError");

    if (interests.length < 2) {
        interestsError.textContent = "Please select at least two areas of interest.";
        formIsValid = false;

        if (!firstInvalidField) {
            firstInvalidField = document.querySelector('input[name="interests"]');
        }
    } else {
        interestsError.textContent = "";
    }

    // Terms
    if (!terms.checked) {
        setError(terms, "You must confirm that the information is correct.");
        formIsValid = false;

        if (!firstInvalidField) {
            firstInvalidField = terms;
        }
    } else {
        setValid(terms);
    }

    // Final result
    if (!formIsValid) {
        firstInvalidField.focus();
        return;
    }

    // In a real application, remove preventDefault() and send to the server.
    successMessage.textContent =
        "Registration successful! All validation rules have passed.";
    successMessage.style.display = "block";

    // For this classroom demonstration, the request is not sent.
    // To inspect a real Network request, remove event.preventDefault()
    // and make sure process.php exists.
});

form.addEventListener("reset", function() {
    setTimeout(function() {
        document.querySelectorAll(".error").forEach(function(error) {
            error.textContent = "";
        });

        document.querySelectorAll("input, select").forEach(function(field) {
            field.classList.remove("invalid", "valid");
        });

        passwordStrength.textContent = "";
        successMessage.style.display = "none";
    }, 0);
});
