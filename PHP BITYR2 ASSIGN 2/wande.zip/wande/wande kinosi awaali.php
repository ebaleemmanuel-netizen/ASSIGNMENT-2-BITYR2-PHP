<!DOCTYPE html>
<html>
    <head>
        <title>Student Form</title>
        <style>
            
            body{
                font-family: Arial, sans-serif;
                background-color: #f2f2f2;
                margin: 0;
                padding: 20px;
            }

            .box{
                background-color: white;
                width: 450px;
                margin: 0 auto;
                padding: 20px;
                border: 1px solid #ccc;
                border-radius: 8px;
                box-shadow: 0 4 10px rgba(0,0,0,0.15);
            }
            h2{
                text-align: center;
            }
            label{
                display: block;
                font-weight: bold;
                margin-top: 10px;
            }
            input[type="text"],
            inout[type="email"],
            input[type="number"],
            input[type="date"],
            input[typ="password"],
            select,
            textarea{
                width: 100%;
                padding: 6px;
                margin-top: 4px;
                box-sizing: border-box;
                border: 1px solid #ccc;
                border-radius: 4px;
            }
            .radio-line{
                margin-top: 4px;
            }
            .radio-line label{
                display: inline;
                font-weight: normal;
                margin-left: 5px;
                margin-right: 15px;
            }
            button{
                width: 100%;
                padding: 10px;
                margin-top: 15px;
                background-color: #007BFF;
                color: white;
                border: none;
                border-radius: 4px;
                font-size: 16px;
                cursor: pointer;
                box-shadow: 0 3px 6px rgba(0,0,0,0.2);
            }
            button:hover{
                background-color: #0056b3;
                box-shadow: 0 5px 10px rgba(0,0,0,0.3);
            }
            .result strong{
                display: inline-block;
                width: 150px;
            }
        </style>
    </head>
    <body>
        <div class="box">
            <h2>Student Registration Form</h2>
            <form action="" method="POST">
                <label>First Name:</label>
                <input type="text" name="firstName" required>
                <label>Last Name:</label>
                <input type="text" name="lastName" required>
                <label>Other Name:</label>
                <input type="text" name="otherName">
                <label>Password:</label>
                <input type="password" name="password" required>
                <label>Email:</label>
                <input type="email" name="email" required>
                <label>Phone:</label>
                <input id="phone" name="Phone" type="tel" pattern="^(\+256|07[0-9]{8}$" placeholder="0701527839" required> 
                <label>Student No</label>              
                <input id="studentNo" name="StudentNo" type="text" pattern="^BIT/[0-9]{4}/[0-9]{4}$" placeholder="BIT/2026/OOO1" required>
                <label>Date of Birth:</label>
                <input type="date" name="dob" required>
                <label>Age</label>
                <input type="number" min="18" max="65" name="age" required>
                <label>Gender</label>
                <select name="gender" required>
                    <option value="">Select</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                </select>
                <label>Major Subject:</label>
                <select name="majorSubject" required>
                    <option value="">Select</option>
                    <option value="CS">Computer Science</option>
                    <option value="IT">Information Technology</option>
                </select>
                <label>Enrollment:</label>
                <div class="radio-line">
                    <input type="radio" name="enrollment" value="Full-Time" required>
                    <label>Full-Time:</label>
                    <input type="radio" name="enrollment" value="Part-Time" required>
                    <label>Part-Time:</label>
                </div>
                <label>CGPA</label>
                <input type="text" name="cgpa" required>
                <label>Emergency Contact Name:</label>
                <input type="emrgencyName" required>
                <label>Emergency Contact Phone:</label>
                <input type="text" name="emrgencyPhone" required>
                <label>Address</label>
                <textarea name="address" rows="3" required></textarea>
                <button type="submit" name="submit">Submit</button>
            </form> 
            <?php
            if (isset($_POST['submit'])){
                echo "<div class='result'>";
                    echo "<h3>Received Data:</h3>";

                    echo "<p><strong>First Name:</strong>".$_POST['firstName']."</p>";
                    echo "<p><strong>Last Name:</strong>".$_POST['lastName']."</p>";
                    echo "<p><strong>Other Name:</strong>".$_POST['otherName']."</p>";
                    echo "<p><strong>Password:</strong>".$_POST['password']."</p>";
                    echo "<p><strong>Email:</strong>".$_POST['email']."</p>";
                    echo "<p><strong>Phone:</strong>".$_POST['phone']."</p>";
                    echo "<p><strong>Student No:</strong>".$_POST['studentNo']."</p>";
                    echo "<p><strong>Date of Birth:</strong>".$_POST['dob']."</p>";
                    echo "<p><strong>Age:</strong>".$_POST['age']."</p>";
                    echo "<p><strong>Gender:</strong>".$_POST['gender']."</p>";
                    echo "<p><strong>Major Subject:</strong>".$_POST['majorSubject']."</p>";
                    echo "<p><strong>Enrollment:</strong>".$_POST['enrollment']."</p>";
                    echo "<p><strong>Emergency Name:</strong>".$_POST['emergencyName']."</p>";
                    echo "<p><strong>Emergency Phone:</strong>".$_POST['emrgencyPhone']."</p>";
                    echo "<p><strong>Address:</strong>".$_POST['address']."</p>";
                    echo "</div>";
            }
            ?>
        </div>
    </body>
</html>