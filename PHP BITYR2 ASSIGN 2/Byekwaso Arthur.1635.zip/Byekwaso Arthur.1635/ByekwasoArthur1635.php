<!DOCTYPE html>
<html>
    <head>
        <title>Student Form</title>
    <style>
        body{
            font-family: Arial, san-serif;
            background-color: #f2f2f2;
            margin:0;
            padding:20px;
        }
        .box{
            background-color: white;
            width:450px;
            margin:0 auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.15);
        }
        h2{
            text-align: center;
        }
        label{
            display: block;
            font-weight: bold;
            margin-top: 10px;

        }
        input[type="text"],
        input[type="email"],
        input[type="number"],
        input[type="date"]
        select,
        textarea{
            width: 100%;
            padding: 6px;
            margin-top: 4px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .radio-line{
            margin-top: 4px;
        }
        .radio-line label{
            display: inline;
            font-weight: normal;
            margin-left: 5px;
            margin-right: 15px;
        }
        button{
            width: 100%;
            padding: 10px;
            margin-top: 15px;
            background-color: #007BFF;
            color: white;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
            box-shadow: 0 3px 6px rgba(0,0,0,0.2);
        }
        button:hover{
            background-color: #0056b3;
            box-shadow: 0 5px 10px rgba(0,0,0,0.3);

        }
        .rasult{
            margin-top: 20px;
            padding-top: 15px;
            border-top: 2px solid #ccc;
        }
        .result p {
            margin: 5px 0;

        }
        .result strong{
            display:inline-block;
            width:150px;
        }
    </style>
    </head>
    <body>
        <div class="box">
            <h2>Student Registration Form</h2>
            <form action="" method="POST">
                <label>First Name</label>
                <input type="text" name="firstName" required>

                <label>Last Name</label>
                <input type="text" name="lastName" required>

                //..Email field
    <!--user type="email" for built-in browser validation(check for@)-->
    <!--'autocomplete' helps browsers autofill saved email addresses. 'required ' means it cannot be left blank-->
                <label>Email</label>
                <input type="email" name="email" required autocomplete="email">

                <label>Password</label>
                <input type="password" name="password" required>

                <label>ConfirmPassword</label>
                <input type="password" name="confirmPassword" required>

                <!--Phone field-->
                <!--uses type='tel' which brings up a numeric keypad on mobile devices.-->
                <!--The 'pattern' attribute uses a regular Expression to enforce a specific format:-->
                    <!--it must start with the Ugandan countyry code(+256) OR a zero (0), followed by exactly 9 digits.-->
                    <!--'required ' means it cannot be left blank-->
                <label>Phone</label>
                <input type="tel" name="phone" pattern="(\+256|0)[0-9]{9}" required>

                <label>Student ID</label>
                <input type="text" name="studentId" required>

                <label>Date of Birth</label>
                <input type="date" name="dob" required>

                <!--Age field-->
                <!--uses type='number' to restrict input to numeric values only-->
                <!--'min="10"' and 'max="75"' set the acceptable range; the form wont submit if the age is outside this.-->
                <!--'required ' means it cannot be left blank-->
                <label>Age</label>
                <input type="number" name="age" min="10" max="75" required>
                <label>Gender</label>
                <select name="gender" required>
                    <option value="">Select</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                </select>
                <label>Major</label>
                <select name="major" required>
                    <option value="">Select</option>
                    <option value="CS">Computer SCience</option>
                    <option value="BIT">Information Technology</option>
                </select>
                <label>Enrollment</label>
                <div class="radio-line">
                <input type="radio" name="enrollment" value="Full-time" required>
                <label>Full Time</label>
                <input type="radio" name="enrollment" value="Part-time"required>
                <label>Part-Time</label>
            </div>

            <!--Academic Year field-->
            <!--uses type="text" for standard text input-->
            <!--the 'pattern' attribute enforces a specific format using Regex: exactly $ digits, a forward slash, then exactly 4 digits (e.g .2023/2024).-->
            <!--'placeholder' provides a visual hint to the user of the expected format.-->
            <!--'required' means it cannot be left blank-->
            <label>Accademic Year</label>
                <input type="text" name="Ayear" pattern="[0-9]{4}/[0-9]{4}" placeholder="2020/2021" required>

                <label>Year of Study</label>
                <input type="text" name="gradeYear" required>

                <label>Parent Name</label>
                <input type="text" name="emergencyName" required>

                <label>Parent Phone number</label>
                <input type="text" name="emergencyPhone" required>

                <label>Address</label>
                <textarea name="address" rows="3" required></textarea>

                <button type="submit" name="submit">Submit</button>

            </form>
            <?php
            //check if the form hass been submitted via POST method
            if (isset($_POST['submit'])){
                //Retrieve the password and confirm password fields from the form
                $pass=$_POST['password'];
                $confirm=$_POST['confirmPassword'];

                //validate that the entered password match
                if($pass !=$confirm){
                    //if they dont match, display an error message
                    echo"<p class='error'>Error:Passwords do not Match!</p>";
                }else{
                    //if password match, begin displaying the submitted data
                echo"<div class='result'>";
                echo"<h3>Receive Data:</h3>";

                //output each submitted form field securely
                echo"<p><strong>First Name:</strong>" . $_POST['firstName'] . "</p>";
                echo"<p><strong>Last Name:</strong>" . $_POST['lastName'] . "</p>";
                echo"<p><strong>Email:</strong>" . $_POST['email'] . "</p>";

                //intentionally hidde the password in the output for security
                echo"<p><strong>Password:</strong>***************(Hidden)</p>";

                //output each submitted form field securely
                echo"<p><strong>Phone:</strong>" . $_POST['phone'] . "</p>";
                echo"<p><strong>Student ID:</strong>" . $_POST['studentId'] . "</p>";
                echo"<p><strong>Date of Birth:</strong>" . $_POST['dob'] . "</p>";
                echo"<p><strong>Age :</strong>" . $_POST['age'] . "</p>";
                echo"<p><strong>Gender:</strong>" . $_POST['gender'] . "</p>";
                echo"<p><strong>Major:</strong>" . $_POST['major'] . "</p>";
                echo"<p><strong>Enrollment:</strong>" . $_POST['enrollment'] . "</p>";
                echo"<p><strong>Accademic Year:</strong>" . $_POST['Ayear'] . "</p>";
                echo"<p><strong>Year of Study:</strong>" . $_POST['gradeYear'] . "</p>";
                echo"<p><strong>Parent Name:</strong>" . $_POST['emergencyName'] . "</p>";
                echo"<p><strong>Parent Phone Number:</strong>" . $_POST['emergencyPhone'] . "</p>";
                echo"<p><strong>Address:</strong>" . $_POST['address'] . "</p>";

                echo"</div>";//close the result container
                }
            }
            ?>
        </div>
    </body>
</html>