<?php
// This file receives the POST request from the registration form.

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    echo "Registration data received successfully.";
} else {
    echo "Please submit the registration form.";
}
?>
